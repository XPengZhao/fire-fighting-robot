#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void RED_ON(void);
void RED_OFF(void);
void GREEN_ON(void);
void GREEN_OFF(void);

#endif
