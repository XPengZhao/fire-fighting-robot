# include "led.h"
# include "delay.h"

int main(void)
{
  delay_init();
  LED_Init();
  while(1)
  {
    RED_ON();
    delay_ms(500);
    GREEN_ON();
    delay_ms(500);
    RED_OFF();
    delay_ms(500);
    GREEN_OFF();
    delay_ms(500);
  }
}
